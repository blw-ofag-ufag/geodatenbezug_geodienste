geodienste.ch, téléchargement
=============================

Thème: Périmètre des vignobles en terrasses
Date de préparation: 19.04.2024 11:05
Cantons: NE
Format de fichier: GeoPackage
Cadre de référence: MN95

Les géodonnées peuvent être obtenues via le lien suivant durant les trois prochains jours:
https://www.geodienste.ch/downloads/lwb_perimeter_terrassenreben/xxFmwjVBA5yMnmipMjch


Remarques générales
-------------------

Veuillez noter que des géométries éventuellement erronées sont automatiquement filtrées et éliminées lors de la préparation des offres à base de fichiers. Le format ESRI Shapefile est soumis à certaines restrictions (2 Go maximum, types de données autorisés, longueur des noms de champs < 11, erreurs d'arrondi potentielles, etc.) Il est recommandé d'utiliser le format GeoPackage. Si vous souhaitez utiliser les données originales des cantons, géométries éventuellement erronées incluses, le format INTERLIS par canton est à votre disposition à la place sous forme de service de téléchargement "AtomFeed + OpenSearch" à l’adresse https://geodienste.ch/atom/download.xml.



Informations détaillées du canton NE
------------------------------------

Cycle de mise à jour:
    annuelle
Date de dernière publication:
    05.12.2023 11:05:06
Cadre de référence des données:
    MN95: initial
Intégralité cantonale:
    Oui
Remarques:
    aucune indication
Contact:
    sitn@ne.ch
Conditions d’utilisation:
    les conditions d’utilisation cantonales s’appliquent (https://sitn.ne.ch/geoshop2_media/documents/contrat_sitn.pdf)
Conditions d’utilisation opendata.swiss:
    Utilisation libre. Obligation d’indiquer la source.
