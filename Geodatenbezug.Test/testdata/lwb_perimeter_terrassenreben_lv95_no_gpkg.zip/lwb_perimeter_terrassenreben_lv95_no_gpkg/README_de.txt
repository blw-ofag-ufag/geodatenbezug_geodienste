geodienste.ch Download
======================

Thema: Perimeter Terrassenreben
Zeitpunkt der Aufbereitung: 19.04.2024 11:05
Kantone: NE
Dateiformat: GeoPackage
Bezugsrahmen: LV95

Die Geodaten können während den nächsten drei Tagen unter folgendem Link bezogen werden:
https://www.geodienste.ch/downloads/lwb_perimeter_terrassenreben/xxFmwjVBA5yMnmipMjch


Allgemeine Bemerkungen
----------------------

Bitte beachten Sie, dass ggf. fehlerhafte Geometrien bei der Aufbereitung der dateibasierten Angebote automatisch herausgefiltert werden. Das Format ESRI Shapefile unterliegt bestimmten Beschränkungen (max. 2 GB, zulässige Datentypen, Länge der Feldnamen < 11, potentielle Rundungsfehler, etc.). Es wird empfohlen, das Format GeoPackage zu nutzen. Falls Sie die Originaldaten der Kantone inkl. allfälliger fehlerhaften Geometrien nutzen möchten, steht Ihnen anstelle das Format INTERLIS kantonsweise als Downlaod-Dienst "AtomFeed + OpenSearch" unter https://geodienste.ch/atom/download.xml zur Verfügung.



Detailinformationen Kanton NE
-----------------------------

Aktualisierungs-Zyklus:
    Jährlich
Zeitstand (letzte Publikation):
    05.12.2023 11:05:06
Bezugsrahmen der Daten:
    LV95: originär
Kantonale Vollständigkeit:
    Ja
Bemerkungen:
    keine Angabe
Kontakt:
    sitn@ne.ch
Nutzungsbedingungen:
    Es gelten die kantonalen Nutzungsbedingungen (https://sitn.ne.ch/geoshop2_media/documents/contrat_sitn.pdf)
opendata.swiss Nutzungsbedingungen:
    Freie Nutzung. Quellenangabe ist Pflicht.
