geodienste.ch Download
======================

Tema: Perimetro vigneti in zone terrazzate
Momento della preparazione: 19.04.2024 11:05
Cantoni: NE
Formato file: GeoPackage
Quadro di riferimento: MN95

I geodati possono essere ottenuti per i prossimi tre giorni al seguente link:
https://www.geodienste.ch/downloads/lwb_perimeter_terrassenreben/xxFmwjVBA5yMnmipMjch


Osservazioni generali
---------------------

Si noti che le eventuali geometrie errate vengono filtrate ed eliminate automaticamente durante la preparazione delle offerte basate su file. Il formato ESRI Shapefile è soggetto ad alcune limitazioni (massimo 2 GB, tipi di dati consentiti, lunghezza dei nomi dei campi < 11, potenziali errori di arrotondamento, ecc.) Si consiglia di utilizzare il formato GeoPackage. Se si desidera utilizzare i dati originali dei Cantoni, comprese eventuali geometrie errate, il formato INTERLIS è disponibile come servizio di download "AtomFeed + OpenSearch" su base cantonale all'indirizzo https://geodienste.ch/atom/download.xml.



Informazioni di dettaglio Cantone NE
------------------------------------

Ciclo di aggiornamento:
    Annuale
Stato attuale (ultima pubblicazione):
    05.12.2023 11:05:06
Quadro di riferimento dei dati:
    MN95: originario
Completezza cantonale:
    Si
Osservazioni:
    nessuna indicazione
Contatto:
    sitn@ne.ch
Condizioni d’uso:
    Valgono le Condizioni d’uso cantonali (https://sitn.ne.ch/geoshop2_media/documents/contrat_sitn.pdf)
opendata.swiss Condizioni d’uso:
    Utilizzo libero. La citazione delle fonti è obbligatoria.
